import pandas as pd
from pathlib import Path


def load_data(filepath):
    """
    Load the dataset from a CSV file
    """
    filepath = Path(filepath).resolve()

    if not filepath.exists():
        raise FileNotFoundError(f"CSV file not found: {filepath}")

    df = pd.read_csv(filepath)
    return df


def handle_missing_values(df):
    """
    Handle missing values:
    - Numerical columns: mean
    - Categorical columns: mode
    """
    num_cols = df.select_dtypes(include=['int64', 'float64']).columns
    df[num_cols] = df[num_cols].fillna(df[num_cols].mean())

    cat_cols = df.select_dtypes(include=['object']).columns
    for col in cat_cols:
        df[col] = df[col].fillna(df[col].mode()[0])

    return df


def drop_unnecessary_columns(df):
    """
    Drop columns not useful for modeling
    """
    if 'student_id' in df.columns:
        df = df.drop('student_id', axis=1)
    return df


def encode_categorical_features(df, target_column):
    """
    One-hot encode categorical features
    """
    X = df.drop(target_column, axis=1)
    y = df[target_column]

    X_encoded = pd.get_dummies(X, drop_first=True)
    return X_encoded, y


def preprocess_data(filepath, target_column):
    """
    Complete preprocessing pipeline
    """
    df = load_data(filepath)
    df = handle_missing_values(df)
    df = drop_unnecessary_columns(df)
    X, y = encode_categorical_features(df, target_column)

    return X, y
