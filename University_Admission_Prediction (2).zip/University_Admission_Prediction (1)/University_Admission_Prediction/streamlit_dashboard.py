import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
from xgboost import XGBRegressor
import os

# -----------------------------
# Page config
# -----------------------------
st.set_page_config(
    page_title="University Admissions Dashboard",
    layout="wide"
)

st.title("🎓 University Admissions Dashboard")

# -----------------------------
# 1️⃣ Load data
# -----------------------------
DATA_PATH = os.path.join("Notebooks", "College_Admission_updated.csv")
df = pd.read_csv(DATA_PATH)

# Ensure year exists
if "year" not in df.columns:
    df["year"] = np.random.randint(2020, 2027, size=len(df))

# -----------------------------
# 2️⃣ Sidebar Filters
# -----------------------------
st.sidebar.header("🔍 Filters")

stream_filter = st.sidebar.multiselect(
    "Preferred Stream",
    df["preferred_stream"].unique(),
    default=df["preferred_stream"].unique()
)

gender_filter = st.sidebar.multiselect(
    "Gender",
    df["gender"].unique(),
    default=df["gender"].unique()
)

filtered_df = df[
    (df["preferred_stream"].isin(stream_filter)) &
    (df["gender"].isin(gender_filter))
]

# -----------------------------
# 3️⃣ Student-level Analysis
# -----------------------------
st.subheader("📘 Student-Level Insights")

col1, col2 = st.columns(2)

with col1:
    fig, ax = plt.subplots(figsize=(5, 3))
    sns.histplot(filtered_df["admission_probability"], kde=True, ax=ax)
    ax.set_title("Admission Probability Distribution")
    st.pyplot(fig, use_container_width=True)

with col2:
    fig, ax = plt.subplots(figsize=(5, 3))
    sns.scatterplot(
        x="entrance_score",
        y="admission_probability",
        data=filtered_df,
        ax=ax
    )
    ax.set_title("Entrance Score vs Admission Probability")
    st.pyplot(fig, use_container_width=True)

# Preferred Stream vs Admission Probability (Horizontal)
fig, ax = plt.subplots(figsize=(6, 3))
sns.barplot(
    x="admission_probability",
    y="preferred_stream",
    data=filtered_df,
    ax=ax
)
ax.set_title("Preferred Stream vs Admission Probability")
ax.set_xlabel("Admission Probability")
ax.set_ylabel("Preferred Stream")
st.pyplot(fig, use_container_width=True)

# Correlation Heatmap
fig, ax = plt.subplots(figsize=(6, 4))
sns.heatmap(
    filtered_df.corr(numeric_only=True),
    cmap="coolwarm",
    ax=ax
)
ax.set_title("Correlation Heatmap")
st.pyplot(fig, use_container_width=True)

# -----------------------------
# 4️⃣ Aggregate Data
# -----------------------------
df["num_admissions"] = 1

agg_df = df.groupby(
    ["college_name", "preferred_stream", "year"]
).agg(
    num_admissions=("num_admissions", "sum"),
    avg_entrance_score=("entrance_score", "mean"),
    avg_board_percentage=("board_percentage", "mean"),
    avg_extracurricular=("extracurricular_score", "mean"),
    avg_admission_probability=("admission_probability", "mean"),
    total_applications=("student_id", "count")
).reset_index()

# -----------------------------
# 5️⃣ Prepare X and y
# -----------------------------
X = agg_df.drop("num_admissions", axis=1)
y = agg_df["num_admissions"]

X = pd.get_dummies(
    X,
    columns=["college_name", "preferred_stream"],
    drop_first=True
)

X_train = X[X["year"] < 2026]
y_train = y.loc[X_train.index]

# -----------------------------
# 6️⃣ Train Model
# -----------------------------
model = XGBRegressor(
    n_estimators=600,
    learning_rate=0.05,
    max_depth=5,
    subsample=0.9,
    colsample_bytree=0.8,
    random_state=42
)

model.fit(X_train, y_train)

# -----------------------------
# 7️⃣ Predict for 2027
# -----------------------------
future_df = agg_df[["college_name", "preferred_stream"]].drop_duplicates()
future_df["year"] = 2027

feature_means = agg_df.groupby(
    ["college_name", "preferred_stream"]
).mean(numeric_only=True).reset_index()

future_df = future_df.merge(
    feature_means,
    on=["college_name", "preferred_stream"],
    how="left"
)

X_future = pd.get_dummies(
    future_df.drop("num_admissions", axis=1),
    columns=["college_name", "preferred_stream"],
    drop_first=True
)

X_future = X_future.reindex(columns=X.columns, fill_value=0)

future_df["predicted_admissions_2027"] = (
    model.predict(X_future).round().astype(int)
)

# -----------------------------
# 8️⃣ Predictions Dashboard
# -----------------------------
st.header("📊 Predicted Admissions for 2027")

col1, col2 = st.columns([1, 2])

with col1:
    college_select = st.selectbox(
        "Select College",
        future_df["college_name"].unique()
    )

college_df = future_df[
    future_df["college_name"] == college_select
]

with col2:
    fig, ax = plt.subplots(figsize=(6, 3))
    sns.barplot(
        x="predicted_admissions_2027",
        y="preferred_stream",
        data=college_df,
        ax=ax
    )
    ax.set_xlabel("Predicted Admissions (2027)")
    ax.set_ylabel("Preferred Stream")
    st.pyplot(fig, use_container_width=True)

# Prediction Table
st.subheader("📄 Full Prediction Table (2027)")
st.dataframe(
    future_df.sort_values(["college_name", "preferred_stream"]),
    height=300
)
